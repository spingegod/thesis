/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "MLX90640_API.h"
#include "MLX90640_I2C_Driver.h"
#include "network.h"
#include "network_data.h"
#include "classifier.h"
#include "classifier_data.h"
#include "ai_platform.h"

#include <stdio.h>
#include <string.h>

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
#define TA_SHIFT 8
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CRC_HandleTypeDef hcrc;

I2C_HandleTypeDef hi2c1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_CRC_Init(void);
static void MX_I2C1_Init(void);
//static void MX_TIM16_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
float min_array(float arr[], int size)
{
  float min = arr[0];
  for(int i=1; i<size; i++)
  {
      if(arr[i] < min)
      {
          min = arr[i];
      }
  }
  return min;
}

float max_array(float arr[], int size)
{
  float max = arr[0];
  for(int i=1; i<size; i++)
  {
      if(arr[i] > max)
      {
          max = arr[i];
      }
  }
  return max;
}

float avg_array(float arr[], int size)
{
  float avg;
  float sum = arr[0];
  for(int i=1; i<size; i++)
  {
    sum = sum + arr[i]; 
  }
  avg = sum/size;
  return avg;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
uint16_t eeMLX90640[832] = {0};
uint16_t mlx90640Frame[834] = {0};
paramsMLX90640 mlx90640;
float mlx90640To[768] = {0.0};
ai_float segmented_image[24][32];
ai_error err;
ai_error err2;
ai_i32 nbatch;
uint32_t timestamp;
ai_network_report report;
ai_network_report report_class;
int n_people_predicted;
int pred_sequence[3] = {0};
int pred_seq_index = 0;
bool first_pred = true;
int current_no_people;
float avg_val;
float threshold;    
float number_thr_pixels;
float adjacency;

int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE BEGIN 1 */
/* Global buffer to handle the activations data buffer - R/W data */
  AI_ALIGNED(32)
  static ai_u8 activations[AI_NETWORK_DATA_ACTIVATIONS_SIZE];
  
  AI_ALIGNED(32)
  static ai_u8 activations_class[AI_CLASSIFIER_DATA_ACTIVATIONS_SIZE];
  
  ai_float in_data[24][32];
  ai_float out_data[3];
  
  ai_float in_data_class[6];
  ai_float out_data_class[3];
  
  // Pointer to our model
  ai_handle network = AI_HANDLE_NULL;
  ai_handle classifier = AI_HANDLE_NULL;
  
  
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_CRC_Init();
  MX_I2C1_Init();
  
    /* Creating the network */
  err = ai_network_create(&network, AI_NETWORK_DATA_CONFIG);
  err2 = ai_classifier_create(&classifier, AI_CLASSIFIER_DATA_CONFIG);
  if (err.type != AI_ERROR_NONE || err2.type != AI_ERROR_NONE) 
  {
    Error_Handler();
  }
  
    /* Initialize param structure for the activation and weight buffers */
  /* initialize network */
  const ai_network_params params = {
  AI_NETWORK_DATA_WEIGHTS(ai_network_data_weights_get()),
  AI_NETWORK_DATA_ACTIVATIONS(activations) };
  
  const ai_network_params params_class = {
  AI_CLASSIFIER_DATA_WEIGHTS(ai_classifier_data_weights_get()),
  AI_CLASSIFIER_DATA_ACTIVATIONS(activations_class) };
  
  if (!ai_network_init(network, &params)) {
    Error_Handler();
  }
  if (!ai_classifier_init(classifier, &params)) {
    Error_Handler();
  }
  
    /*Copy descriptor info*/
  ai_buffer ai_input = {(int32_t) AI_NETWORK_IN };
  
  ai_buffer ai_output = {(int32_t) AI_NETWORK_OUT };
  
  ai_buffer ai_input_class = {(int32_t) AI_CLASSIFIER_IN };
  
  ai_buffer ai_output_class = {(int32_t) AI_CLASSIFIER_OUT };
  
  /*Retrieve network descriptor*/
  ai_network_get_info(network, &report);
  ai_classifier_get_info(classifier, &report_class);
  
  /*Copy descriptor info*/
  ai_input = report.inputs[0];
  ai_output = report.outputs[0];
  
  ai_input_class = report_class.inputs[0];
  ai_output_class = report_class.outputs[0];
  
  /* initialize input/output buffer handlers */
  ai_input.data = AI_HANDLE_PTR(in_data);
  ai_output.data = AI_HANDLE_PTR(out_data);
  
  ai_input_class.data = AI_HANDLE_PTR(in_data_class);
  ai_output_class.data = AI_HANDLE_PTR(out_data_class);
  
  /* USER CODE BEGIN 2 */
  float emissivity = 0.97;
  float tr;
  int status;
  int mode;
  status = MLX90640_SetRefreshRate(0x33,0x04);
  status = MLX90640_GetRefreshRate(0x33);
  status = MLX90640_DumpEE (0x33, eeMLX90640);
  status = MLX90640_ExtractParameters(eeMLX90640, &mlx90640);
  
  // Start timer/counter
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
    for (int x = 0 ; x < 4 ; x++) //Read both subpages
    {
      status = MLX90640_GetFrameData(0x33, mlx90640Frame);
      
      mode = MLX90640_GetCurMode(0x33);
      
      tr = MLX90640_GetTa(mlx90640Frame, &mlx90640) - TA_SHIFT;

      MLX90640_CalculateTo(mlx90640Frame, &mlx90640, emissivity, tr, mlx90640To);
    }
    MLX90640_BadPixelsCorrection((&mlx90640)->brokenPixels, mlx90640To, mode, &mlx90640);
    MLX90640_BadPixelsCorrection((&mlx90640)->outlierPixels, mlx90640To, mode, &mlx90640);
    int n = 0;
    float f;
    threshold = (2*avg_array(mlx90640To, 768)+max_array(mlx90640To, 768))/3;
    memset(segmented_image, 0.0, sizeof(segmented_image));
    for (int x = 0; x < 24; x++)
    {
      for (int y = 0; y < 32; y++)
      {
        memcpy(&f, &mlx90640To[n], 4);
        in_data[x][y] = f;
        if(f > threshold)
        {
          segmented_image[x][y] = f; 
        }
        n++;
      }
    }
    //Colect features for classifier
    avg_val = avg_array(mlx90640To, 768);
    
    number_thr_pixels = 0;
    for (int i=0; i<32; i++)
    {
        for (int j=0; j<24; j++)
        {
          if (in_data[j][i] > threshold)
          {
            number_thr_pixels++;
          }
        }
    }
    
    adjacency = 0;
    for (int i=0; i<24; i++)
    {
      bool adj_bool = false;
      for (int j=1; j<32; j++)
      {
        if (segmented_image[i][j] > 0 && segmented_image[i][j-1] > 0)
        {
          if(adj_bool != true)
          {
            adjacency++;
          }
          adj_bool = true;
        }
        else
        {
          if(adj_bool != 0)
          {
            adjacency++;
          }
          adj_bool = false;
        }
      }
    }
    
    
    
    // Get current timestamp
    //timestamp = htim16.Instance->CNT;

    // Perform inference
 
    ai_i32 result = ai_network_run(network, &ai_input, &ai_output);
    err = ai_network_get_error(network);
    
    
    in_data_class[0] = avg_val;
    in_data_class[1] = number_thr_pixels;
    in_data_class[2] = adjacency;
    memcpy(&f, &out_data[0], 4);
    in_data_class[3] = f;
    memcpy(&f, &out_data[1], 4);
    in_data_class[4] = f;
    memcpy(&f, &out_data[2], 4);
    in_data_class[5] = f;
    
    ai_i32 result_class = ai_classifier_run(classifier, &ai_input_class, &ai_output_class);
    err2 = ai_classifier_get_error(classifier);
    
        /*Deliver prediction*/
    if(out_data_class[0] > out_data_class[1] && out_data_class[0] > out_data_class[2])
    {
      n_people_predicted = 0;
    }
    else if(out_data_class[1] > out_data_class[0] && out_data_class[1] > out_data_class[2])
    {
      n_people_predicted = 1;
    }
    else
    {
      n_people_predicted = 2;
    }
    
    if (first_pred)
    {
      pred_sequence[0] = n_people_predicted;
      pred_sequence[1] = n_people_predicted;
      pred_sequence[2] = n_people_predicted;
      first_pred = false;
    }
    else
    {
      pred_sequence[pred_seq_index] = n_people_predicted;
      if (pred_seq_index == 2)
      {
        pred_seq_index = 0;
      }
      else
      {
        pred_seq_index++;
      }
      int zeros = 0;
      int ones = 0; 
      int twos = 0;
      
      for(int x = 0; x < 3; x++)
      {
        if(pred_sequence[x] == 0)
        {
          zeros++;
        }
        else if(pred_sequence[x] == 1)
        {
          ones++;
        }
        else
        {
          twos++;
        }
      }
      if(zeros > ones && zeros > twos)
      {
        current_no_people = 0;
      }
      else if(ones > zeros && ones > twos)
      {
        current_no_people = 1;
      }
      else if(twos > ones && twos > zeros)
      {
        current_no_people = 2;
      }
      else
      {
        current_no_people = n_people_predicted;
      }
    }
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_SET);
    if (current_no_people == 1)
    {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_RESET);
        HAL_Delay(500);
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_SET);
    }
    else if(current_no_people == 2)
    {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_RESET);
        HAL_Delay(200);
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_SET);
        HAL_Delay(100);
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_RESET);
        HAL_Delay(200);
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_SET);
    }
    else
    {
      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_SET);
    }
    
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CRC Initialization Function
  * @param None
  * @retval None
  */
static void MX_CRC_Init(void)
{

  /* USER CODE BEGIN CRC_Init 0 */

  /* USER CODE END CRC_Init 0 */

  /* USER CODE BEGIN CRC_Init 1 */

  /* USER CODE END CRC_Init 1 */
  hcrc.Instance = CRC;
  hcrc.Init.DefaultPolynomialUse = DEFAULT_POLYNOMIAL_ENABLE;
  hcrc.Init.DefaultInitValueUse = DEFAULT_INIT_VALUE_ENABLE;
  hcrc.Init.InputDataInversionMode = CRC_INPUTDATA_INVERSION_NONE;
  hcrc.Init.OutputDataInversionMode = CRC_OUTPUTDATA_INVERSION_DISABLE;
  hcrc.InputDataFormat = CRC_INPUTDATA_FORMAT_BYTES;
  if (HAL_CRC_Init(&hcrc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CRC_Init 2 */

  /* USER CODE END CRC_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x10909CEC;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM16 Initialization Function
  * @param None
  * @retval None
  */
/*
static void MX_TIM16_Init(void)
{

  htim16.Instance = TIM16;
  htim16.Init.Prescaler = 80-1;
  htim16.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim16.Init.Period = 65535;
  htim16.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim16.Init.RepetitionCounter = 0;
  htim16.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim16) != HAL_OK)
  {
    Error_Handler();
  }

}
*/
/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  
    /*Configure GPIO pin : PC9 */
  GPIO_InitStruct.Pin = GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
 
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_SET);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

